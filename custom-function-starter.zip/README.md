# custom-functions-starter

add custom functions

**Important**: Credentials file is used register functions. Do not push this file to any external
 repository. 

**Important**  When using a private repository you will add your personal 
access token to the PACKAGE_URL in `register.py`.
To prevent leaking your personal access token do NOT push the register.py file to your github. Either delete your 
token before you push the file or add it to .gitignore